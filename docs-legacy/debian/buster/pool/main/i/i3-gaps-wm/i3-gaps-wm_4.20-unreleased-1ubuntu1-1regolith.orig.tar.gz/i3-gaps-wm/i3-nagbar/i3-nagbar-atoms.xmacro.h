// clang-format off
#define NAGBAR_ATOMS_XMACRO \
xmacro(_NET_WM_WINDOW_TYPE) \
xmacro(_NET_WM_WINDOW_TYPE_DOCK) \
xmacro(_NET_WM_STRUT_PARTIAL) \
xmacro(I3_SOCKET_PATH) \
xmacro(ATOM) \
xmacro(CARDINAL)
