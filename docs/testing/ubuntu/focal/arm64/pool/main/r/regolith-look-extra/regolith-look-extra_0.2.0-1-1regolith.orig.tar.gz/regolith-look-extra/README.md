# regolith-look-extra

Regolith Looks are discrete configurations of desktop components that together that define the capabilities and flavor of a desktop interface.  This package houses looks created and maintained by the Regolith project.

## Status

This repo is in active development and is entirely unstable.