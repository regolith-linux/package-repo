# I did not merge this file in _static to be easily parsable by the setup script
ROFICATION_NAME = 'rofication'
ROFICATION_URL = 'https://github.com/regolith-linux/regolith-rofication'
ROFICATION_VERSION = '1.2.2'
