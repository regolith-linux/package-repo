// clang-format off
#define CONFIG_WIZARD_ATOMS_XMACRO		\
xmacro(_NET_WM_NAME) \
xmacro(_NET_WM_WINDOW_TYPE) \
xmacro(_NET_WM_WINDOW_TYPE_DIALOG) \
xmacro(ATOM) \
xmacro(CARDINAL) \
xmacro(UTF8_STRING)
