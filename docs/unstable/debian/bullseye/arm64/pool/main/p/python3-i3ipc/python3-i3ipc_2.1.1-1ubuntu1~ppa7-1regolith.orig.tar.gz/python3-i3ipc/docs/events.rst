Events
======

.. autoclass:: i3ipc.Event
   :members:
   :undoc-members:

.. autoclass:: i3ipc.WorkspaceEvent
   :members:
   :undoc-members:

.. autoclass:: i3ipc.WindowEvent
   :members:
   :undoc-members:

.. autoclass:: i3ipc.BarconfigUpdateEvent
   :members:
   :undoc-members:

.. autoclass:: i3ipc.BindingInfo
   :members:
   :undoc-members:

.. autoclass:: i3ipc.BindingEvent
   :members:
   :undoc-members:

.. autoclass:: i3ipc.TickEvent
   :members:
   :undoc-members:

.. autoclass:: i3ipc.ModeEvent
   :members:
   :undoc-members:

.. autoclass:: i3ipc.OutputEvent
   :members:
   :undoc-members:

.. autoclass:: i3ipc.ShutdownEvent
   :members:
   :undoc-members:

.. autoclass:: i3ipc.InputEvent
   :members:
   :undoc-members:
